# Project 0
By:Zahi Masarwa

Web Programming with Python and JavaScript

this project includes 6 main files as 4 of them they are Html coding and 1 Css style and 1 Scss 
that was already converted to the CSS file.

the 4 HTML file are:
MainPage.html
Secondrypage.html
Symptoms.html
Worldwide.html

all those files include Html coding and added to that bootstrap design and links to pagestyling.css to make designing for the page.

Symptoms.html and Worldwide.html they include a link for a design from ScssStyle

the file PageStyling includes all the styling needed for the page that includes properties and selectors and special design for classes and id.

Scssstyle page include inheritance and nesting and variables