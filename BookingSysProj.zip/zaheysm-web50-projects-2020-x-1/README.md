# Project 1

in my programming, there is 4 python files and 7 HTML files and 1 CSS file

the python files are:
1.Create.py file is a file to create the tables in the database.
2.import.py file to import book.csv to the table in the database.
3.models.py are the tables in the database which is the base to create it in the DataBase.
4.application.py is the main file that all the coding of the Website.

the Html files are:
1.index.html is the Main Entrance to the database where you can log in to the website.
2.Search.html is the page where the search of the books results get and links to book pages.
3.bookpage.html is the book page where you get the information of the book include ratings and information from GoodReads.
4.register.html is the page where you register to the website.
5.layout.html is the base layout for all pages.
6.success and success_regiester is page success for registering and successfully adding a rating.
7.pagestyling.css is the page style of the website.