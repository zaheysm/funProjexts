import requests,csv,requset,os
res = requests.get("https://www.goodreads.com/book/review_counts.json", params={"key": "nHCYjBDisyz0g5gAITTSA", "isbns": "9781632168146"})
print(res.json())