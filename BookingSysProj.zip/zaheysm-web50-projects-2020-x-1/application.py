import os,requests
from flask import Flask, render_template, request,session,redirect,jsonify
from flask_session import Session
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from datetime import timedelta
from models import *

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
db.init_app(app)
Session(app)

engine = create_engine(os.getenv("DATABASE_URL"))
db = scoped_session(sessionmaker(bind=engine))

@app.route("/",methods=["GET","POST"])
def index():
    if request.method=="POST":
        username=request.form.get('name') 
        password=request.form.get('Password')
        if db.execute("SELECT username,password FROM users WHERE username=:username and password=:password",{"username":username,"password":password}).rowcount==0:
            Error_Message='Username or Password are Inccorect'
            return render_template("index.html",Error_Message=Error_Message)
        session["username"]=username
        return render_template("search.html",name=session["username"],book1=db.execute("SELECT title FROM books WHERE author = 'Jodi Picoult'").fetchall())
    Error_Message=''
    return render_template("index.html",Error_Message=Error_Message)
    

@app.route("/register" ,methods=["GET","POST"])
def register():
    Error_Message=''
    return render_template("register.html",Error_Message=Error_Message)

@app.route("/registered",methods=["POST"])
def registered():
    username = request.form.get("user_name")
    Password = request.form.get("Password")
    First_name = request.form.get("First_name")
    Last_name = request.form.get("Last_name")
    Email = request.form.get("Email")
    confirm_password= request.form.get("confirm_password")
    usernamedouble=db.execute("SELECT username FROM users WHERE username=:username",{"username":username}).fetchone()
    if usernamedouble is not None:
        Error_Message="Please Select a Different Username, the One You Choose is in Use"
        return render_template("register.html",Error_Message=Error_Message)
    if confirm_password != Password:
        Error_Message="Password Don't Match"
        return render_template("register.html",Error_Message=Error_Message)
    if confirm_password == Password:
        if username is not None and Password is not None and First_name is not None and Last_name is not None and Email is not None:
            db.execute("INSERT INTO users (username, first_name, last_name, password, email) VALUES (:username,:first_name,:last_name,:password,:email)",
                {"username": username, "first_name":First_name, "last_name":Last_name, "password":Password, "email":Email})
            db.commit()
            db.close()
            
        else:
            Error_Message="Password Don't Match"
            return render_template("register.html",Error_Message=Error_Message)
    db.close()
    message='You Have Been Registered Successfully'
    return render_template("success.html",message=message)  

def searchresult(result):
    books=db.execute("SELECT * FROM books WHERE LOWER(author) LIKE :author or LOWER(title) LIKE :title or LOWER(isbn) LIKE :isbn" ,{"author":"%"+result+"%","title":"%"+result+"%","isbn":"%"+result+"%"}).fetchall()
    db.commit()
    return books


@app.route("/searchbook",methods=["POST"]) 
def searchbook():
    if session.get("username") is None:
            Error_Message='Please Enter Username And Password'
            return render_template("index.html",Error_Message=Error_Message)
    result=request.form.get('search').lower()
    books=searchresult(result)
    if result=='' or len(books)==0:
        massage='Search Query Returned no Result, Please Try Another Search'
        return render_template("search.html",name=session["username"],massage=massage)

    db.close()
    return render_template("search.html",books=books,name=session["username"],)

@app.route("/books/<int:book_id>",methods=["GET","POST"])
def books(book_id):
    if session.get("username") is None:
        Error_Message='Please Enter Username And Password'
        return render_template("index.html",Error_Message=Error_Message)
    Error_Message=''

    bookname=db.execute("SELECT * FROM books WHERE id = :book_id",{"book_id":book_id}).fetchall()
    Reviews=db.execute("SELECT review FROM reviews WHERE bookid=:book_id",{"book_id":book_id}).fetchall()
    rating=db.execute("SELECT avg(rating) FROM reviews WHERE bookid=:book_id",{"book_id":book_id}).fetchall()
    res = requests.get("https://www.goodreads.com/book/review_counts.json", params={"key": "nHCYjBDisyz0g5gAITTSA", "isbns": bookname[0][1]})
    if res.status_code==404:
        try:
            if len(bookname[0])==7:
                 res = requests.get("https://www.goodreads.com/book/review_counts.json", params={"key": "nHCYjBDisyz0g5gAITTSA", "isbns": '000'+bookname[0][1]})
            elif len(bookname[0])==8:
                res = requests.get("https://www.goodreads.com/book/review_counts.json", params={"key": "nHCYjBDisyz0g5gAITTSA", "isbns": '00'+bookname[0][1]})
            else:
                res = requests.get("https://www.goodreads.com/book/review_counts.json", params={"key": "nHCYjBDisyz0g5gAITTSA", "isbns": '0'+bookname[0][1]})   
        except:
            Goodreads_Rating_Average='No Rating on GoodReads'
    gvr=res.json()
    for i in gvr['books']:
        Goodreads_Rating_Number=i['work_ratings_count']
        Goodreads_Rating_Average=i['average_rating']

    if rating[0][0] is None:
        rate="No Rating has Been Submited Yet. You're Welcome to Submit One."
    else:
        rate=float("{:.2f}".format(rating[0][0]))
    return render_template("bookpage.html",books=bookname,Reviews=Reviews,Error_Message=Error_Message,rate=rate,Goodreads_Rating_Average=Goodreads_Rating_Average,Goodreads_Rating_Number=Goodreads_Rating_Number,name=session["username"])

@app.route("/addrating/<int:book_id>",methods=["POST"])
def addrating(book_id):
    if session.get("username") is None:
        Error_Message='Please Enter Username And Password'
        return render_template("index.html",Error_Message=Error_Message)
    bookname=db.execute("SELECT * FROM books WHERE id = :book_id",{"book_id":book_id})
    userid=db.execute("SELECT id FROM users WHERE username = :username",{"username":session["username"]}).fetchone()
    Reviews=db.execute("SELECT review FROM reviews WHERE bookid=:book_id",{"book_id":book_id}).fetchall()
    rating=db.execute("SELECT avg(rating) FROM reviews WHERE bookid=:book_id",{"book_id":book_id}).fetchall()
    user_id=int(userid[0])
    if rating[0][0] is None:
        rate="No Rating has Been Submited Yet. You're Welcome to Submit One."
    else:
        rate=float("{:.2f}".format(rating[0][0]))
    ifstate=db.execute("SELECT userid,bookid FROM reviews WHERE bookid=:book_id and userid=:userid",{"book_id":book_id,"userid":user_id}).fetchone()
    
    if ifstate is None:
        addreview=request.form.get('review')
        addrate=request.form.get('ratingchoice')
        db.execute("INSERT INTO reviews (review,rating,bookid,userid) VALUES (:review,:rating,:bookid,:userid)",
                        {"review":addreview,"rating":addrate,"bookid":book_id,"userid":user_id})        
        db.commit()
        db.close()
        message='You Have Successfully Added a Rating to the Book.'
        return render_template("success_register.html",message=message,book_id=book_id,username=session["username"])
    else:
        Error_Message="A Review Has Been Previously Submited, you Cannot Submit a Second."
        return render_template("bookpage.html",books=bookname,Reviews=Reviews,Error_Message=Error_Message,rate=rate)


@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect("/")

@app.route ("/success",methods=["POST"])
def success():
    message='You Have Successfully Added a Rating to the Book'
    return render_template("success.html",message=message)

@app.route("/api/<string:isbn>")
def book_api(isbn):
    book=db.execute("SELECT * FROM books WHERE isbn = :isbn",{"isbn":isbn}).fetchone()
    if book is None:
        return jsonify({"error": "Invalid isbn"}),404
    avgrating=db.execute("SELECT avg(rating),count(review) FROM reviews WHERE bookid=:book_id",{"book_id":book[0]}).fetchone()
    return jsonify({
            "title": book["title"],
            "author": book["author"],
            "year": book["year"],
            "isbn": book["isbn"],
            "review_count": avgrating[1],
            "average_score": float("{:.2f}".format(avgrating[0]))
    })