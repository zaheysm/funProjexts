import os
import requests

from flask import Flask, jsonify, render_template, request
from flask_socketio import SocketIO, emit

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY")
socketio = SocketIO(app)


chats=[]
users=[]
channelslist=[]
#messages={}
allmessges=[]

@app.route("/")
def index():
    return render_template("index.html", chats=chats,users=users)

@socketio.on("enterchat")
def chatting(data):
    messages={}
    chats=data['message']
    user=data['username']
    timestamp=data['timestamp']
    user_and_time=(f"{user} {timestamp}".format())
    messages[data['channel']]={user_and_time:chats}
    allmessges.append(messages)
    for channel in channelslist:
        counter=0
        for messges in allmessges:
            for j in messges:
                if j==channel:
                    counter+=1
                    if counter==1:
                        d1=allmessges.index(messges)
                    if counter==101:
                        del allmessges[d1]
    emit("announce chatting",messages,broadcast=True)

@socketio.on("channelsadded")
def addchannel(data):
    channel=data['channel']
    if (channel not in channelslist) and (channel !=None):   
        channelslist.append(channel)
    emit("Adding Channel",channelslist,broadcast=True)

@socketio.on("change channel")
def changechannel(data):            
    emit("Channel channged",allmessges,broadcast=True)


@socketio.on("addusers")
def adduser(data):
    if data['username'] not in users:
        users.append(data['username'])
    emit('adduser')

@socketio.on("loadusers")
def loadusers(data):
    emit("load",users,broadcast=True)

@socketio.on("privatechat")
def privatechat(data):
    user=data['username']
    otheruser=data['otheruser']
    timestamp=data['timestamp']
    message=data['message']
    user_and_time=(f"{user} {timestamp}".format())
    messages={user_and_time:message}
    privateuser=[user,otheruser]
    emit("privatemessage",{"messages":messages,"privateuser":privateuser},broadcast=True)

    

