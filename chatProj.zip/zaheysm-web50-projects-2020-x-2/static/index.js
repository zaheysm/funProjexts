
if(!localStorage.getItem('channel'))
    localStorage.setItem('channel',"general")
document.addEventListener('DOMContentLoaded',()=>{
    var socket = io.connect(location.protocol + '//' + document.domain + ':' + location.port);

    document.querySelector("#newchannel").style.visibility='hidden';
    document.querySelector('#btnchannel').style.visibility='hidden';
    document.querySelector("#choose_user").style.visibility='hidden';
    document.querySelector('#btnchannel').disabled = true;
    document.querySelector('#send').disabled = false;
    if(!localStorage.getItem('username')){
        document.querySelector('#mainchat').style.visibility='hidden';
        document.querySelector("#username").disabled=false;
        alert("Please Enter User Name")
    }
    else{
        document.querySelector('#mainchat').style.visibility='visible'
        document.querySelector("#username").disabled=true;
        document.querySelector("#username").value=localStorage.getItem('username')
    }

    socket.on('connect', () => {
        const store=localStorage.getItem('channel')
        socket.emit('channelsadded', {"channel":store})

        var select=document.querySelector("#select_channel")
        select.value=store
        
        socket.emit('change channel',{"channel":store})

        document.querySelector("#btnadduser").onclick=()=>{
            const username=document.querySelector("#username").value;
            document.querySelector('#mainchat').style.visibility='visible'
            document.querySelector("#username").disabled=true;
            localStorage.setItem('username',username)
            const users=document.querySelector('#choose_user')
            for (var i=0;i<users.length;i++){
                if(users[i].text===username){
                    alert('Username is Used Choose Another')
                    break;
                }
            }
            socket.emit('addusers',{"username":username})
        }

        document.querySelector('#select_channel').onchange=function(){
            const error=document.getElementById("duplicate");
            error.innerHTML=''
            if (this.value==='addchannel'){
                document.querySelector("#Message_box").value=''
                document.querySelector("#newchannel").style.visibility='visible';
                document.querySelector("#btnchannel").style.visibility='visible';
                
                document.querySelector("#newchannel").onkeyup= () => {
                    if (document.querySelector('#newchannel').value.length > 0)
                        document.querySelector('#btnchannel').disabled = false;
                    else
                        document.querySelector('#btnchannel').disabled = true;

                    document.querySelector("#btnchannel").onclick=() =>{
                        document.querySelector("#newchannel").style.visibility='hidden';
                        document.querySelector("#btnchannel").style.visibility='hidden';
                        const channel=document.querySelector("#newchannel").value;
                        for (var i=0;i<this.length;i++){
                            if(this[i].text===channel){
                                error.innerHTML="The Channel That you are Trying to add already exsist please type another one"
                                this.selectedIndex="general";
                                break;
                            }
                        }
                        socket.emit('channelsadded', {"channel":channel});
                    }
                }
            }
        else{
            document.querySelector("#Message_box").value=''
            socket.emit('change channel',{"channel":this.value});

}};
var cheackbox=document.querySelector("#privatecheck");
cheackbox.addEventListener('click',function (){
    const username=document.querySelector("#username").value;
    if (this.checked===true){
        document.querySelector("#choose_user").style.visibility='visible';
        document.querySelector("#Message_box").value=''
        socket.emit('loadusers',{"username":username})
    }
    else
        document.querySelector("#choose_user").style.visibility='hidden'
        socket.emit('change channel',{"channel":store})
});
    
    document.querySelector("#message").onkeyup=()=>{
        if (document.querySelector('#message').value.length > 0)
            document.querySelector('#send').disabled = false;
        else
            document.querySelector('#send').disabled = true;
        document.querySelector('#send').onclick = () => {
            const username=document.querySelector("#username").value;
            const message=document.querySelector("#message").value;
            const channel=document.querySelector("#select_channel").value;
            const otheruser=document.querySelector("#choose_user").value;
            var today = new Date();
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            var timestamp = date+' '+time;
            if (cheackbox.checked==true){
                socket.emit('privatechat', {"channel":channel,'message': message,"username":username,"otheruser":otheruser,"timestamp":timestamp});
            }
            else{
                
                socket.emit('enterchat', {"channel":channel,'message': message,"username":username,"timestamp":timestamp});
            }
        }
    }
    document.querySelector("#message").onfocus= ()=>{
        document.getElementById('message').value='';
    }
    
    socket.on('announce chatting', data => {
        var div = document.querySelector("#Message_box");
        
        const ch = document.querySelector("#select_channel").value;
        const usernamesender=document.querySelector("#username").value;
        for (let i in  data) {
            if (i===ch){
                for (let j in  data[ch])
                div.innerHTML+=`${j} message is :${data[ch][j]}<br>`
            };
        };
        div.scrollTop=div.scrollHeight;

    });


    socket.on('privatemessage', data => {
        var div = document.querySelector("#Message_box");
        users=data.privateuser
        const ch = document.querySelector("#select_channel").value;
        const username=document.querySelector("#username").value;
        const otheruser=document.querySelector("#choose_user").value;
        messages=data.messages
            if ((users[0]===username && users[1]==otheruser) || (users[1]===username && users[0]==otheruser)){
                for (let j in  messages)
                div.innerHTML+=`${j} message is :${messages[j]}<br>`
            };
        div.scrollTop=div.scrollHeight;

    });

    socket.on('Adding Channel',data => {
        var opt=document.getElementById("select_channel")
        for (let i in data){
            if (data[i]!="" && data[i]!="general"){
                var counter=0
                for (var j=0;j<opt.length;j++){
                    if(data[i]===opt[j].innerText){
                        counter++;
                    }
                }
                if (counter===0){
                    const option=document.createElement("option");
                    option.text=data[i]
                    document.querySelector("#select_channel").append(option);
                }}
            };
        if (localStorage.getItem('channel'))
            opt.value=store;
        if (opt.value==='addchannel')
            opt.selectedIndex="general";
    });

    socket.on('Channel channged', data =>{
        const channel=document.querySelector("#select_channel").value;
        document.querySelector('#Message_box').innerHTML='';
        localStorage.setItem('channel',channel)
        loadchats(data,channel)
});

socket.on('load',data =>{
    const select=document.getElementById("choose_user");
    const len=document.getElementById("choose_user").length-1;
    if (len>0){
        for (var j=len;j>=0;j--)
            select.remove(j)
    }
    for (let i in data){
        if (data[i]!=""){
            const option=document.createElement("option");
            option.text=data[i]
            select.append(option);
        }
    }



})

function loadchats(data,channel){
    if (data===''){
        return false;
    }
    for (let i in  data) {
        for (let j in data[i]){
            if (j===channel){
                for (let k in  data[i][j]){
                    var div = document.querySelector("#Message_box");
                    div.innerHTML+=`${k} message is :${data[i][j][k]}<br>`
                }
            }};
};

}
});
});
