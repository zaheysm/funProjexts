# Project 2

Web Programming with Python and JavaScript

in my project, there are two folders that each contain one file and one file without a folder

in folder static, the javascript code is there which include my whole code

in the folder templates is the HTML file 

the lonely file without a folder is application.py which include my the python code 


my program also supports private messaging